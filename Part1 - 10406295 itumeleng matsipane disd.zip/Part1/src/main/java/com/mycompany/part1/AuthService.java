/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part1;

import java.util.Scanner;

/**
 *
 * @author ChangeMe
 */
public class AuthService {
    
    private User registeredUser;

    public void register(Scanner sc) {
        System.out.print("Enter username: ");
        String username = sc.nextLine();

        if (!Validator.isValidUsername(username)) {
            System.out.println("Invalid username. Must contain '_' and be <= 5 characters.");
            return;
        }

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        if (!Validator.isValidPassword(password)) {
            System.out.println("Invalid password. Must be 8 chars, include uppercase, number, and special char.");
            return;
        }

        registeredUser = new User(username, password);
        System.out.println("Registration successful!");
    }

    public void login(Scanner sc) {
        if (registeredUser == null) {
            System.out.println("No user registered yet.");
            return;
        }

        System.out.print("Enter username: ");
        String username = sc.nextLine();
        System.out.print("Enter password: ");
        String password = sc.nextLine();

        if (username.equals(registeredUser.getUsername()) && password.equals(registeredUser.getPassword())) {
            System.out.println("Welcome ** ,** it is great to see you again!");
        } else {
            System.out.println("Username or password incorrect, please try again.");
        }
    }
}
    

