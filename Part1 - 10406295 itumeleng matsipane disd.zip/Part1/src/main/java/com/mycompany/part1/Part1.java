/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part1;

import java.util.Scanner;

/**
 *
 * @author ChangeMe
 */
public class Part1 {

    public static void main(String[] args) {
       
        //Scanner
                Scanner sc = new Scanner(System.in);
        AuthService authService = new AuthService();

        System.out.println("=== User Registration ===");
        authService.register(sc);

        System.out.println("\n=== User Login ===");
        authService.login(sc);

        sc.close();
    }
    }

